import requests
from bs4 import BeautifulSoup
import csv

# Define URL and headers
URL = "https://example.com/products"
HEADERS = {"User-Agent": "Mozilla/5.0"}

def scrape_data():
    product_list = []
    for page in range(1, 5):  # Scrape multiple pages
        response = requests.get(f"{URL}?page={page}", headers=HEADERS)
        soup = BeautifulSoup(response.text, 'html.parser')

        for product in soup.find_all("div", class_="product-item"):
            title = product.find("h2").text.strip()
            price = product.find("span", class_="price").text.strip()
            product_list.append([title, price])

    return product_list

def save_to_csv(data):
    with open("products.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Product Name", "Price"])
        writer.writerows(data)

if __name__ == "__main__":
    data = scrape_data()
    save_to_csv(data)
    print("Scraping complete. Data saved to products.csv.")
