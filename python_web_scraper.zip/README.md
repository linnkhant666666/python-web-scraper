# Python Web Scraper

## 📌 Description
This is a simple web scraper that extracts product data from an e-commerce website and saves it to a CSV file.

## 🔧 Features
- Scrapes product titles and prices from multiple pages.
- Stores data in a structured CSV format.
- Uses BeautifulSoup for parsing HTML.

## 🚀 How to Use
1. Install dependencies:  
   ```bash
   pip install requests beautifulsoup4
   ```
2. Run the script:  
   ```bash
   python web_scraper.py
   ```

## 📌 Requirements
- Python 3.x
- `requests` and `beautifulsoup4` packages

Enjoy coding! 🚀
